"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8201:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "react-icons/ri"
const ri_namespaceObject = require("react-icons/ri");
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./pages/_app.js






const Menu = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "p-6 active:text-violet-700 hover:text-pink-400 ",
                        children: "Buy NFT"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/create-nft",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "p-6 active:text-violet-700 hover:text-pink-400 ",
                        children: "Create NFT"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/my-nfts",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "p-6 active:text-violet-700 hover:text-pink-400 ",
                        children: "My NFTs"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/dashboard",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "p-6 active:text-violet-700 hover:text-pink-400 ",
                        children: "All Nfts"
                    })
                })
            })
        ]
    })
;
function MyApp({ Component , pageProps  }) {
    const { 0: toggleMenu , 1: setToggleMenu  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: " p-3 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "https://bitcoin-uni.de/assets/images/kompl.-b-day-mode-14x-8-192x151.png",
                                    className: "h-14 w-16 p-1"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " text-2xl pt-4 text-white lg:flex max-w-xl:hidden sm:hidden hidden ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " flex ml-40 ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Menu, {})
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-2xl flex pt-4 lg:hidden absolute right-5 ",
                                children: toggleMenu ? /*#__PURE__*/ jsx_runtime_.jsx(ri_namespaceObject.RiCloseLine, {
                                    color: "#fff",
                                    size: 37,
                                    onClick: ()=>setToggleMenu(false)
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(ri_namespaceObject.RiMenu3Line, {
                                    color: "#fff",
                                    size: 37,
                                    onClick: ()=>setToggleMenu(true)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " lg:hidden flex justify-center",
                        children: toggleMenu && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: " flex-col text-xl text-white font-semibold flex justify-center ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Menu, {})
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " bg-black h-70 ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-rows-1 grid-flow-col gap-3 text-white justify-center ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-5 p-10 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "pb-5 text-lg",
                                    children: "Legal"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: " mb-2 mr-6 ",
                                    children: "Terms of use"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: " mb-2 mr-1 ",
                                    children: "Privacy policy"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: " mb-2 mr-1 ",
                                    children: "Contact"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-5 p-10 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "pb-5 text-lg",
                                    children: "Links"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "https://bitcoin-uni.de",
                                    children: [
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: " mb-2 mr-6 ",
                                            children: "Guide"
                                        }),
                                        " "
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [895,664,675], () => (__webpack_exec__(8201)));
module.exports = __webpack_exports__;

})();